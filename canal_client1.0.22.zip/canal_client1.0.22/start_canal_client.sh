java -cp ./lib/*:./canal_client.jar  canal.client.CanalClientTest
